from django.shortcuts import render
def index(request):
    return render(request,"guestapp/index.html")
def about(request):
    return render(request,"guestapp/about.html")

def blog(request):
    return render(request,"guestapp/blog.html")

def post(request):
    return render(request,"guestapp/post-details.html")        

def contact(request):
    return render(request,"guestapp/contact.html")    